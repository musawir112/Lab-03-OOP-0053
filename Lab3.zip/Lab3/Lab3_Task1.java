class Lab3_Task1{
public static void main(String []args){
int start=2;
int end=20;

for(int num=start;num<=end;num++){
boolean isPrime=true;
	for(int j=2;j<num;j++){
	 if(num%j==0){
	 isPrime=false;
	 break;
	}
	}
if (isPrime){

System.out.println(num);
}

}

}
}
