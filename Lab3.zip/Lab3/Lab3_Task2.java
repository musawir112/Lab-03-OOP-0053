class Lab3_Task2{
public static void main(String [] args){
String text="levelssssssss";

String rev="";
System.out.println(text);
  for(int i=text.length()-1;i>=0;i--){
  rev=rev+text.charAt(i);
}
if (text.equals(rev)){
System.out.println("palindrome");
}
else{
System.out.println("Not palindrome");


}

}
}